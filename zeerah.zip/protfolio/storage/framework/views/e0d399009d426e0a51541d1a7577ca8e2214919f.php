<div class="top-nav wow " id="fixedmenu">
    <div class="container">
        <div class="navbar-header logo">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                Menu
            </button>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <div class="menu">
                <ul class="nav navbar">
                    <li><a href="#about" class="scroll">About</a></li>
                    <li><a href="#work" class="scroll">Experience</a></li>
                    <li><a href="#education" class="scroll">Education</a></li>
                    <li><a href="#skills" class="scroll">Skills</a></li>
                    <li><a href="#projects" class="scroll">My Projects</a></li>
                    <li><a href="#contact" class="scroll">Contact</a></li>
                </ul>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\protfolio\resources\views/frontend/inc/menu.blade.php ENDPATH**/ ?>