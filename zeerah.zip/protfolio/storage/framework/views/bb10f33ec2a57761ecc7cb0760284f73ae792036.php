

<?php if(\Session::has('success')): ?>
    <div class="alert alert-card alert-success" role="alert">
        <strong class="text-capitalize">Success! </strong>
        <?php echo e(\Illuminate\Support\Facades\Session::get('success')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>

<?php if(\Session::has('error')): ?>
    <div class="alert alert-card alert-danger" role="alert">
        <strong class="text-capitalize">Error! </strong>
        <?php echo e(\Illuminate\Support\Facades\Session::get('error')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if($errors->count() > 0 ): ?>
    <div class="alert alert-danger" role="alert">
        <strong class="text-capitalize">The following errors have occurred:</strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($message); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?><?php /**PATH G:\xampp\htdocs\protfolio\resources\views/admin/inc/messages.blade.php ENDPATH**/ ?>