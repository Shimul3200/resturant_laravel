<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1.0
    </div>
    <strong>All Rights Reserved by Shimul Nath &copy; 2019</strong>
</footer>
<?php /**PATH C:\xampp\htdocs\protfolio\resources\views/admin/inc/footer.blade.php ENDPATH**/ ?>