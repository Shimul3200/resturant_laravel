<!DOCTYPE html>
<html>
<head>
    <title>SHIMUL DEB NATH</title>
    <!--mobile apps-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="My Resume Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>

    <link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" type="text/css" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('frontend/css/style.css')); ?>" type="text/css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/css/swipebox.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/js/fancybox/jquery.fancybox.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/js/owl.carousel/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/js/owl.carousel/owl.theme.default.min.css')); ?>">

    <script src="<?php echo e(asset('frontend/js/jquery-1.11.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/move-top.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/easing.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/jquery.nicescroll/jquery.nicescroll.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/fancybox/jquery.fancybox.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('frontend/js/owl.carousel/owl.carousel.min.js')); ?>"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
            });
        });
    </script>
    <!--//end-smooth-scrolling-->
</head>
<body>
<!--banner-->
<?php echo $__env->make('frontend.inc.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--//banner-->
<!--top-nav-->
<?php echo $__env->make('frontend.inc.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--//top-nav-->
<!--about-->
<?php echo $__env->make('frontend.inc.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--//about-->
<!--work-experience-->
<div id="work" class="work">
    <div class="container">
        <h3 class="title">Work Experience</h3>
        <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="work-info">
                <div class="col-md-6 work-left">
                    <h4><?php echo e($ex->year); ?> </h4>
                </div>
                <div class="col-md-6 work-right">
                    <h5><span class="glyphicon glyphicon-briefcase"> </span> <?php echo e($ex->c_name); ?> </h5>
                    <p><?php echo e($ex->desc); ?></p>
                </div>
                <div class="clearfix"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="clearfix"></div>
</div>
</div>
</div>
<!--//work-experience-->
<!--education-->
<div id="education" class="education">
    <div class="container">
        <h3 class="title">Education</h3>

        <div class="work-info">
            <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 work-left">
                    <h4><?php echo e($education->e_name); ?>- <?php echo e($education->year); ?></h4>
                </div>
                <div class="col-md-6 work-right">
                    <h5><span class="glyphicon glyphicon-education"> </span> <?php echo e($education->ins_name); ?></h5>
                    <p> <?php echo e($education->desc); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
        </div>

        
    </div>
</div>

<!--skills-->
<div id="skills" class="skills">
    <div class="container">
        <h3 class="title">Programming Knowloge</h3>
        <div class="skills-info">
            <div class="col-md-6 bar-grids">
                <h6>WEB DESIGN <span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
                <h6>HTML/CSS<span>95% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 95%">
                    </div>
                </div>
                <h6>jQuery <span> 75% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 75%">
                    </div>
                </div>
                <h6>Ajax <span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
            </div>
            <div class="col-md-6 bar-grids">
                <h6>JS <span> 60% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 60%">
                    </div>
                </div>
                <h6>PHP<span> 90% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 90%">
                    </div>
                </div>
                <h6>LARAVEL<span>90% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 90%">
                    </div>
                </div>
                <h6>WORDPRESS<span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--//education-->
<!--portfolio-->
<div id="projects" class="portfolio">
    <div class="container">
        <h3 class="title wow zoomInLeft animated" data-wow-delay=".5s">My Projects</h3>
        <div class="sap_tabs">
            <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
                <ul class="resp-tabs-list wow fadeInUp animated" data-wow-delay=".7s">
                    <li class="resp-tab-item"><span>All</span></li>
                    <li class="resp-tab-item"><span>Html</span></li>
                    <li class="resp-tab-item"><span>Php</span></li>
                    <li class="resp-tab-item"><span>Wordpress</span></li>
                </ul>
                <div class="clearfix"></div>
                <div class="resp-tabs-container">
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g1.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g1.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid effect-sarah">
                                    <a href="<?php echo e(asset('frontend/images/g2.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g2.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g3.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g3.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g4.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g4.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g5.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g5.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g6.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g6.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g7.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g7.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g8.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g8.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g9.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g9.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g5.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g5.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g6.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g6.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g7.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g7.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g3.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g3.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g1.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g1.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g9.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g9.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g2.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g2.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g4.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g4.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="<?php echo e(asset('frontend/images/g8.jpg')); ?>" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="<?php echo e(asset('frontend/images/g8.jpg')); ?>" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--ResponsiveTabs-->
        <script src="<?php echo e(asset('frontend/js/easyResponsiveTabs.js')); ?>" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#horizontalTab').easyResponsiveTabs({
                    type: 'default', //Types: default, vertical, accordion
                    width: 'auto', //auto or any width like 600px
                    fit: true   // 100% fit in a container
                });
            });
        </script>
        <!--//ResponsiveTabs-->
        <!-- swipe box js -->
        <script src="<?php echo e(asset('frontend/js/jquery.swipebox.min.js')); ?>"></script>
        <script type="text/javascript">
            jQuery(function ($) {
                $(".swipebox").swipebox();
            });
        </script>
        <!-- //swipe box js -->
    </div>
</div>
<!--//portfolio-->
<!--contact -->
<div class="welcome contact" id="contact">
    <div class="container">
        <h3 class="title">Contact Us</h3>
        <div class="contact-row">
            <div class="col-md-6 contact-left">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d250261.21285550427!2d-60.42919264432581!3d46.13039392716506!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4b67ef033cc4082f%3A0xbf0517bb7d9ecd34!2sNorth+Sydney%2C+NS%2C+Canada!5e0!3m2!1sen!2sin!4v1460613320469"></iframe>
            </div>
            <div class="col-md-6 contact-right">
                <div class="address-left">
                    <p>Moulvibazar-3200,Sylhet<br> Dhaka,Bangladesh </p>
                </div>
                <div class="address-right">
                    <p>Call me : +88 017 90 204070</p>
                    <p>E-mail : <a href="shimulnath016@gmail.com">shimulnath016@gmail.com</a></p>
                </div>
                <div class="clearfix"></div>
                <br/>

                <div class="contact-form">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <br/>
                    <?php endif; ?>
                    <?php echo Form::open(['route' => 'notification.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

                    <input class="field" name="name" type="text" placeholder="name" required>
                    <input class="field" name="email" type="email" placeholder="email" >
                    <input class="field" name="number" type="text" placeholder="Phone" >
                    <textarea name="msg" placeholder="Message" required></textarea>
                    <input type="submit" value="SUBMIT" name="submit">

                    <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--//contact -->
<!--footer-->
<?php echo $__env->make('frontend.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--//footer-->
<!--smooth-scrolling-of-move-up-->
<script type="text/javascript">
    // Scroll bar code here.
    $("body").niceScroll({
        cursorcolor: "#008B8B",
        cursorborder: "0px solid #fff",
        cursorwidth: "16px"
    });

    $('.owl-carousel').owlCarousel();

    $(document).ready(function () {

        var defaults = {
            containerID: 'toTop', // fading element id
            containerHoverID: 'toTopHover', // fading element hover id
            scrollSpeed: 1200,
            easingType: 'linear'
        };

        $().UItoTop({easingType: 'easeOutQuart'});

        ///owl-carousel


        var owl = $('.owl-carousel');
        owl.owlCarousel({
            items: 4,
            loop: true,
            autoplay: true,
            autoplayTimeout: 1000,
            autoplayHoverPause: true
        });
        $('.play').on('click', function () {
            owl.trigger('play.owl.autoplay', [1000])
        })
        $('.stop').on('click', function () {
            owl.trigger('stop.owl.autoplay')
        })


    });
</script>
<script src="<?php echo e(asset('frontend/js/bootstrap.js')); ?>"></script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\protfolio\resources\views/frontend/master.blade.php ENDPATH**/ ?>