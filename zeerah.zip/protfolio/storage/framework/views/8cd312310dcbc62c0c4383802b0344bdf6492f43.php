<div id="home" class="banner">
    <div class="banner-info">
        <div class="container">
            <div class="col-md-4 header-left">
                <a href="<?php echo e(asset('frontend/images/me2.jpeg')); ?>" class="swipebox" title="My Name is Shimul Deb NAth. I'm a web developer in laravel and php">
                    <img src="<?php echo e(asset('frontend/images/me2.jpeg')); ?>" alt=""/>
            </div>
            <div class="col-md-8 header-right">
                <h2>Look Me</h2>
                <div class="typetextcolor">
                    <h1>Hi,I'm
                        <a href="" class="typewrite" data-period="2000" data-type='["SHIMUL DEB NATH." ]'>
                            <span class="wrap"></span>
                        </a>
                    </h1>
                </div>
                <h6>Web Designer and Developer</h6>
                <ul class="address">
                    <li>
                        <ul class="address-text">
                            <li><b>D.O.B</b></li>
                            <li>08 July 1999</li>
                        </ul>
                    </li>
                    <li>
                        <ul class="address-text">
                            <li><b>PHONE </b></li>
                            <li>+8801790204070</li>
                            <li>,+8801784107272</li>
                        </ul>
                    </li>
                    <li>
                        <ul class="address-text">
                            <li><b>ADDRESS </b></li>
                            <li>Moulvibazar-3200,Sylhet,Dhaka</li>
                        </ul>
                    </li>
                    <li>
                        <ul class="address-text">
                            <li><b>E-MAIL </b></li>
                            <li><a href="http:\\shimulnath016@gmail.com"> shimulnath016@gmail.com </a></li>
                        </ul>
                    </li>
                    <li>
                        <ul class="address-text">
                            <li><b>WEBSITE </b></li>
                            <li><a href="http://shimulnath.ga">www.shimulnath.ga</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\protfolio\resources\views/frontend/inc/top.blade.php ENDPATH**/ ?>