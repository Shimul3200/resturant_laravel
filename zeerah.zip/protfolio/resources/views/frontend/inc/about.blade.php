<div id="about" class="about">
    <div class="container">
        <h3 class="title"> About Me</h3>
        <div class="col-md-8 about-left">
            <p>Hello, I am Shimul. I am student at Green International University(GIU) </p></br>
            <p>To build up career as an Executive in the Pharmaceutical Industries either in the national or in the multinational company, I would like to implement my knowledge, creativity and innovative thinking in this field.<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse laoreet sem sit amet dolor luctus pellentesque Nam egestas molestie elit. Vivamus sed accumsan quam, a mollis magna. Nam aliquet eros eget sapien consequat</p>
            <br/><p>To build up career as an Executive in the Pharmaceutical Industries either in the national or in the multinational company, I would like to implement my knowledge, creativity and innovative thinking in this field.<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse laoreet sem sit amet dolor luctus pellentesque Nam egestas molestie elit. Vivamus sed accumsan quam, a mollis magna. Nam aliquet eros eget sapien consequat</p>

        </div>
        <div class="col-md-4 about-right">
            <div class="about-img">
                <img src="{{asset('frontend/images/ss.jpg')}}" alt=""/>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
