<div class="footer">
    <div class="container">
        <div class="col-lg-12"><span>
				@All copy right & develop by Shimul Nath
			</span></div>
    </div>
</div>
