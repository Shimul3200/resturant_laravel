<!DOCTYPE html>
<html>
<head>
    <title>SHIMUL DEB NATH</title>
    <!--mobile apps-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="My Resume Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
	SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>

    <link href="{{asset('frontend/css/bootstrap.css')}}" type="text/css" rel="stylesheet" media="all">
    <link href="{{asset('frontend/css/style.css')}}" type="text/css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="{{asset('frontend/css/swipebox.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/js/fancybox/jquery.fancybox.min.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/js/owl.carousel/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('frontend/js/owl.carousel/owl.theme.default.min.css')}}">

    <script src="{{asset('frontend/js/jquery-1.11.1.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/move-top.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/easing.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/custom.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/jquery.nicescroll/jquery.nicescroll.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/fancybox/jquery.fancybox.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('frontend/js/owl.carousel/owl.carousel.min.js')}}"></script>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            $(".scroll").click(function (event) {
                event.preventDefault();
                $('html,body').animate({scrollTop: $(this.hash).offset().top}, 1000);
            });
        });
    </script>
    <!--//end-smooth-scrolling-->
</head>
<body>
<!--banner-->
@include('frontend.inc.top')
<!--//banner-->
<!--top-nav-->
@include('frontend.inc.menu')
<!--//top-nav-->
<!--about-->
@include('frontend.inc.about')
<!--//about-->
<!--work-experience-->
<div id="work" class="work">
    <div class="container">
        <h3 class="title">Work Experience</h3>
    {{--    @foreach($experiences as $ex)
            <div class="work-info">
                <div class="col-md-6 work-left">
                    <h4>{{$ex->year}} </h4>
                </div>
                <div class="col-md-6 work-right">
                    <h5><span class="glyphicon glyphicon-briefcase"> </span> {{$ex->c_name}} </h5>
                    <p>{{$ex->desc}}</p>
                </div>
                <div class="clearfix"></div>
            </div>
        @endforeach--}}
    </div>
    <div class="clearfix"></div>
</div>
</div>
</div>
<!--//work-experience-->
<!--education-->
<div id="education" class="education">
    <div class="container">
        <h3 class="title">Education</h3>

        <div class="work-info">
          {{--  @foreach($educations as $education)
                <div class="col-md-6 work-left">
                    <h4>{{$education->e_name}}- {{$education->year}}</h4>
                </div>
                <div class="col-md-6 work-right">
                    <h5><span class="glyphicon glyphicon-education"> </span> {{$education->ins_name}}</h5>
                    <p> {{$education->desc}}</p>
                </div>
            @endforeach--}}
            <div class="clearfix"></div>
        </div>

        {{--<div class="work-info">
            <div class="col-md-6 work-right work-right2">
                <h4>Secondary School Certificate- 2015</h4>
            </div>
            <div class="col-md-6 work-left work-left2">
                <h5> Kashinath Alauddin High School & College <span class="glyphicon glyphicon-education"></span></h5>
                <p>Kashinath Alauddin High School is one of the most renowned and prehistorical schools of Moulvibazar, Bangladesh. It was established back in 1917 during British Period. The students of this school are currently stationed all over the world and working for the betterment of different states and society. In this age of globalization, Kashinath Alauddin High School is dedicated to introduce modern facilities for the betterment of students, teaching staffs and all the people connected to the school.</p>
            </div>
            <div class="clearfix"> </div>
        </div>--}}
    </div>
</div>

<!--skills-->
<div id="skills" class="skills">
    <div class="container">
        <h3 class="title">Programming Knowloge</h3>
        <div class="skills-info">
            <div class="col-md-6 bar-grids">
                <h6>WEB DESIGN <span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
                <h6>HTML/CSS<span>95% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 95%">
                    </div>
                </div>
                <h6>jQuery <span> 75% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 75%">
                    </div>
                </div>
                <h6>Ajax <span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
            </div>
            <div class="col-md-6 bar-grids">
                <h6>JS <span> 60% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 60%">
                    </div>
                </div>
                <h6>PHP<span> 90% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 90%">
                    </div>
                </div>
                <h6>LARAVEL<span>90% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 90%">
                    </div>
                </div>
                <h6>WORDPRESS<span> 80% </span></h6>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped active" style="width: 80%">
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--//education-->
<!--portfolio-->
<div id="projects" class="portfolio">
    <div class="container">
        <h3 class="title wow zoomInLeft animated" data-wow-delay=".5s">My Projects</h3>
        <div class="sap_tabs">
            <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">
                <ul class="resp-tabs-list wow fadeInUp animated" data-wow-delay=".7s">
                    <li class="resp-tab-item"><span>All</span></li>
                    <li class="resp-tab-item"><span>Html</span></li>
                    <li class="resp-tab-item"><span>Php</span></li>
                    <li class="resp-tab-item"><span>Wordpress</span></li>
                </ul>
                <div class="clearfix"></div>
                <div class="resp-tabs-container">
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g1.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g1.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid effect-sarah">
                                    <a href="{{asset('frontend/images/g2.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g2.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g3.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g3.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g4.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g4.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g5.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g5.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g6.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g6.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g7.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g7.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g8.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g8.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g9.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g9.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g5.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g5.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g6.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g6.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g7.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g7.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g3.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g3.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g1.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g1.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g9.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g9.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                    <div class="tab-1 resp-tab-content">
                        <div class="tab_img">
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g2.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g2.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g4.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g4.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-4 portfolio-grids">
                                <div class="grid">
                                    <a href="{{asset('frontend/images/g8.jpg')}}" class="swipebox"
                                       title="Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis maximus tortor diam, ac lobortis justo rutrum quis. Praesent non purus fermentum, eleifend velit non">
                                        <img src="{{asset('frontend/images/g8.jpg')}}" alt="" class="img-responsive"/>
                                        <div class="figcaption">
                                            <h3>My<span> Project</span></h3>
                                            <p>Sarah likes to watch clouds. She's quite depressed.</p>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--ResponsiveTabs-->
        <script src="{{asset('frontend/js/easyResponsiveTabs.js')}}" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#horizontalTab').easyResponsiveTabs({
                    type: 'default', //Types: default, vertical, accordion
                    width: 'auto', //auto or any width like 600px
                    fit: true   // 100% fit in a container
                });
            });
        </script>
        <!--//ResponsiveTabs-->
        <!-- swipe box js -->
        <script src="{{asset('frontend/js/jquery.swipebox.min.js')}}"></script>
        <script type="text/javascript">
            jQuery(function ($) {
                $(".swipebox").swipebox();
            });
        </script>
        <!-- //swipe box js -->
    </div>
</div>
<!--//portfolio-->
<!--contact -->
<div class="welcome contact" id="contact">
    <div class="container">
        <h3 class="title">Contact Us</h3>
        <div class="contact-row">
            <div class="col-md-6 contact-left">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d250261.21285550427!2d-60.42919264432581!3d46.13039392716506!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4b67ef033cc4082f%3A0xbf0517bb7d9ecd34!2sNorth+Sydney%2C+NS%2C+Canada!5e0!3m2!1sen!2sin!4v1460613320469"></iframe>
            </div>
            <div class="col-md-6 contact-right">
                <div class="address-left">
                    <p>Moulvibazar-3200,Sylhet<br> Dhaka,Bangladesh </p>
                </div>
                <div class="address-right">
                    <p>Call me : +88 017 90 204070</p>
                    <p>E-mail : <a href="shimulnath016@gmail.com">shimulnath016@gmail.com</a></p>
                </div>
                <div class="clearfix"></div>
                <br/>

                <div class="contact-form">
                    @if ($errors->any())
                        <div class="alert alert-danger">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                        <br/>
                    @endif
                    {!! Form::open(['route' => 'notification.store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
                    <input class="field" name="name" type="text" placeholder="name" required>
                    <input class="field" name="email" type="email" placeholder="email" >
                    <input class="field" name="number" type="text" placeholder="Phone" >
                    <textarea name="msg" placeholder="Message" required></textarea>
                    <input type="submit" value="SUBMIT" name="submit">

                    {!! Form::close() !!}
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!--//contact -->
<!--footer-->
@include('frontend.inc.footer')
<!--//footer-->
<!--smooth-scrolling-of-move-up-->
<script type="text/javascript">
    // Scroll bar code here.
    $("body").niceScroll({
        cursorcolor: "#008B8B",
        cursorborder: "0px solid #fff",
        cursorwidth: "16px"
    });

    $('.owl-carousel').owlCarousel();

    $(document).ready(function () {

        var defaults = {
            containerID: 'toTop', // fading element id
            containerHoverID: 'toTopHover', // fading element hover id
            scrollSpeed: 1200,
            easingType: 'linear'
        };

        $().UItoTop({easingType: 'easeOutQuart'});

        ///owl-carousel


        var owl = $('.owl-carousel');
        owl.owlCarousel({
            items: 4,
            loop: true,
            autoplay: true,
            autoplayTimeout: 1000,
            autoplayHoverPause: true
        });
        $('.play').on('click', function () {
            owl.trigger('play.owl.autoplay', [1000])
        })
        $('.stop').on('click', function () {
            owl.trigger('stop.owl.autoplay')
        })


    });
</script>
<script src="{{asset('frontend/js/bootstrap.js')}}"></script>
</body>
</html>

