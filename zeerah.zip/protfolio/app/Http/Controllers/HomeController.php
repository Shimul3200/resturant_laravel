<?php

namespace App\Http\Controllers;

use App\Charts\Charts\MyChart;
use App\Education;
use App\Experience;
use Illuminate\Http\Request;

class HomeController extends Controller
{

    public function index()
    {
        $educations = Education::orderBy('id','asc')->get();
        $experiences = Experience::orderBy('id','desc')->get();
        $chart = new MyChart();


        //  $chart->minimalist(true );
        $chart->dataset('My dataset', 'pie', [80, 30, 20,10 ]);
           // ->color($borderColors)
            //->backgroundcolor($fillColors);;
        $chart->labels(['Delivered', 'Return', 'Cancel', 'Hold']);
        return view('home',\compact('chart'));
    }
}
