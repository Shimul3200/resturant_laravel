<?php

namespace App\Http\Controllers;

use App\Experience;
use Illuminate\Http\Request;

class ExperienceController extends Controller
{
    public function index()
    {
        $results = Experience::all();
        return view('admin.experience.index')->with('results', $results);
    }
    public function create()
    {
        return view('admin.experience.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'c_name' => 'required',
            'year' => 'required',
            'desc' => 'required',
            'status' => 'nullable'
        ]);

        $experience = new Experience();
        $experience->c_name = $request->c_name;
        $experience->year = $request->year;
        $experience->desc = $request->desc;
        $experience->status = $request->status;
        $experience->save();
        return redirect('/experience')->with('success','Experience successfully created.');
    }

    public function show(experience $experience)
    {
        //
    }

    public function edit($id)
    {
        $result = Experience::find($id);
        return view('admin.experience.edit')->with('result', $result);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request, [
            'c_name' => 'required',
            'year' => 'required',
            'desc' => 'required',
            'status' => 'nullable'
        ]);

        $experience = Experience::find($id);
        $experience->c_name = $request->c_name;
        $experience->year = $request->year;
        $experience->desc = $request->desc;
        $experience->status = $request->status;
        $experience->save();
        return redirect('/experience')->with('success','Experience successfully Updated!');
    }

    public function destroy($id)
    {
        $data = Experience::find($id);
        $data->delete();
        return 1;
    }
}
