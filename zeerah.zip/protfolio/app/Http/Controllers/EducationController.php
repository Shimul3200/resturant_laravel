<?php

namespace App\Http\Controllers;

use App\Education;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EducationController extends Controller
{
    public function index()
    {
        $results = Education::all();
        return view('admin.education.index')->with('results', $results);
    }
    public function create()
    {
        return view('admin.education.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'e_name' => 'required',
            'year' => 'required',
            'ins_name' => 'required',
            'desc' => 'required'
        ]);

        $education = new Education();
        $education->e_name = $request->e_name;
        $education->year = $request->year;
        $education->ins_name = $request->ins_name;
        $education->desc = $request->desc;
        $education->save();
        return redirect('/education')->with('success','Education successfully created.');
    }

    public function show(education $education)
    {
        //
    }

    public function edit($id)
    {
        $result = Education::find($id);
        return view('admin.education.edit')->with('result', $result);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request, [
            'e_name' => 'required',
            'year' => 'required',
            'ins_name' => 'required',
            'desc' => 'required'
        ]);
        $education = Education::find($id);
        $education->e_name = $request->e_name;
        $education->year = $request->year;
        $education->ins_name = $request->ins_name;
        $education->desc = $request->desc;
        $education->save();
        return redirect('/education')->with('success', 'Education Successfully Updated!');
    }

    public function destroy($id)
    {
        $data = Education::find($id);
        $data->delete();
        return 1;
    }
}
