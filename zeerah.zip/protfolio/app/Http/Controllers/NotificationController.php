<?php

namespace App\Http\Controllers;

use App\Notification;
use Illuminate\Http\Request;

class NotificationController extends Controller
{

    public function index()
    {
        $results = Notification::latest()->get();
        return view('admin.notification.index')->with('results', $results);
    }


    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $request->validate([
            'name'=>'required|max:40',
            'email' => 'nullable|unique:notifications',
            'number' => 'required',
            'msg' => 'required|max:500'

        ]);
        $notifications = new Notification();
        $notifications->name = $request->name;
        $notifications->email = $request->email;
        $notifications->number = $request->number;
        $notifications->msg = $request->msg;

        $notifications->save();

        return redirect()->back();
    }

    public function show(Notification $notification)
    {
        //
    }


    public function edit(Notification $notification)
    {
        //
    }

    public function update(Request $request, Notification $notification)
    {
        //
    }

    public function destroy($id)
    {
        $data = Notification::find($id);
        $data->delete();
        return 1;
    }
}
